import React from 'react'

export default function Nopage() {
  return (
    <div>opps page not found</div>
  )
}
